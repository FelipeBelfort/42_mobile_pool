package com.example.diary_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
